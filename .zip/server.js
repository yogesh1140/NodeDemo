var express = require('express'),
    bodyParser = require('body-parser'),
    path = require('path'),
    // router = require('./routes/router'),
    //  database = require('./lib/database')
    //  passport = require('passport'),
    port = process.env.PORT || 3000,
    multer = require('multer'),
    app = express(),

    DIR = './uploads/';

class Server {

    constructor() {
        // this.initViewEngine();
        this.initExpressMiddleWare();
        // this.initCustomMiddleware();
        // this.initDbSeeder();
        this.initRoutes();
        this.start();
    }

    start() {
        //  app.use(passport.initialize());
        // app.use(passport.session());
        //   require('./lib/passport')(passport);
        app.listen(port, (err) => {
            console.log('[%s] Listening on http://localhost:%d', process.env.NODE_ENV, port);
        });
    }
    initExpressMiddleWare() {

        app.use(express.static(__dirname + '/dist/TimeSheet'));
        app.use(bodyParser.urlencoded({ extended: true }));
        app.use(bodyParser.json());

        app.use(function (req, res, next) { //allow cross origin requests
            res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
            res.header("Access-Control-Allow-Origin", "*");
            res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
            res.header("Access-Control-Allow-Credentials", true);
            next();
        });

        process.on('uncaughtException', (err) => {
            if (err) console.log(err, err.stack);
        });
    }

    initRoutes() {

        // redirect all others to the index (HTML5 history)
        app.get('/api/timesheet/template', (req, res) => {
            res.download('D:/Personal.lic')
        })

        app.get('/api/json', (req, res) => {
            res.download('D:/Timesheet/dist/company.json')
        })

        var upload = multer({
            storage: multer.diskStorage({
                destination: function (req, file, cb) {
                    cb(null, DIR)
                },
                filename: function (req, file, cb) {
                    cb(null, file.originalname)
                }
            })
        }).any();

        app.post('/api/upload', function (req, res) {
            upload(req, res, function (err) {
                if (err) {
                    return res.status(501).send({ msg: err.toString() });
                }

                res.status(201).send({ msg: 'File is uploaded' });
            });
        });

        // app.all('*', (req, res) => {
        //     res.sendFile(__dirname + '/dist/TimeSheet/index.html');
        // });

        app.get('/app/*', function (req, res) {
            res.sendStatus(404);
        });

        app.get('/node_modules/*', function (req, res) {
            res.sendStatus(404);
        });

        app.get('/home', function (req, res) {
            res.sendFile(__dirname + '/dist/TimeSheet/index.html');
        });
        app.get('/dashboard', function (req, res) {
            res.sendFile(__dirname + '/dist/TimeSheet/index.html');
        });
        app.get('/admindashboard', function (req, res) {
            res.sendFile(__dirname + '/dist/TimeSheet/index.html');
        });
        app.get('/404', function (req, res) {
            res.sendFile(__dirname + '/dist/TimeSheet/index.html');
        });

        app.get('*', function (req, res) {
            console.log('404 error', req.path);
            res.status(400).redirect('/404');
        });

    }

    initCustomMiddleware() {
        if (process.platform === "win32") {
            require("readline").createInterface({
                input: process.stdin,
                output: process.stdout
            }).on("SIGINT", () => {
                console.log('SIGINT: Closing MongoDB connection');
                // database.close();
            });
        }

        process.on('SIGINT', () => {
            console.log('SIGINT: Closing MongoDB connection');
            // database.close();
        });
    }
    // initDbSeeder() {
    //     database.open(() => {
    //         //Set NODE_ENV to 'development' and uncomment the following if to only run
    //         //the seeder when in dev mode
    //         //if (process.env.NODE_ENV === 'development') {
    //         //  seeder.init();
    //         //} 

    //         //seeder.init();
    //     });
    // }
}
var server = new Server();
