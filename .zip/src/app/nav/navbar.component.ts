import { Component, ViewEncapsulation } from '@angular/core';
import { ConfirmService } from '../common/confirm.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import {  } from '@angular/compiler/src/core';

@Component({
  selector: 'app-navbar',
  templateUrl: 'navbar.component.html',
  styles: [`
    .nav.navbar-nav {font-size:15px}
    #searchForm {margin-right:100px; }
    @media (max-width: 1200px) {#searchForm {display:none}}
    li > a.active { color: #F97924; }
    .nav li :hover { background-color: #ddd; }
  `],

})
export class NavBarComponent {
  constructor(private confirmService: ConfirmService, private modalService: NgbModal) { }
  confirm() {
    this.confirmService.confirm({ title: 'Confirm deletion', message: 'Do you really want to delete this foo?' }).then(
      () => {
        console.log('deleting...');
      },
      () => {
        console.log('not deleting...');
      });
  }
}
