import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './routes';
import { AuthService } from './user/auth.service';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { ToastrModule } from 'ngx-toastr';
import { NgDatepickerModule } from 'ng2-datepicker';

import { NavBarComponent } from './nav/navbar.component';
import { HomeComponent } from './home.component';
import { LoginComponent } from './user/login.component';
import { DashboardComponent } from './timesheet/dashboard.component';
import { AdminDashBoardComponent } from './timesheet/admin-dashboard.component';
import { TimeSheetService } from './timesheet/shared/timesheet.service';


import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FileUploadModule } from 'ng2-file-upload';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { InlineEditComponent } from './timesheet/inline-edit.component';
import { Error404Component } from './errors/404.component';

import { ConfirmModalComponent } from './common/confirm-modal.component';
import { ConfirmTemplateDirective } from './common/confirm-template.directive';
import { ConfirmService } from './common/confirm.service';
import { ConfirmState } from './common/confirm-state.service';

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    AdminDashBoardComponent,
    InlineEditComponent,
    Error404Component,
    ConfirmModalComponent,
    ConfirmTemplateDirective

  ],
  imports: [
    HttpClientModule,
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    NgDatepickerModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot(appRoutes),
    NgbModule.forRoot(), HttpClientModule,
    FileUploadModule,
    NgxDatatableModule


  ],
  providers: [AuthService, TimeSheetService, ConfirmService, ConfirmState],
  bootstrap: [AppComponent]
})
export class AppModule { }
