import { Component } from '@angular/core';
import { ConfirmState } from './confirm-state.service';

/**
 * The component displayed in the confirmation modal opened by the ConfirmService.
 */
@Component({
    selector: 'confirm-modal-component',
    template: `
<div class="modal-header">
   <h4 class="modal-title">{{options.title}}</h4>
   <button type="button" class="close" aria-label="Close"  (click)="no()">
   <span aria-hidden="true">&times;</span>
   </button>
</div>
<div class="modal-body">
   <p>{{options.message}}</p>
</div>
<div class="modal-footer">
   <button type="button" class="btn btn-success" (click)="yes()">Yes</button>
   <button type="button" class="btn btn-secondary" (click)="no()">Close</button>
</div>
  `
})
export class ConfirmModalComponent {

    options: ConfirmOptions;

    constructor(private state: ConfirmState) {
        this.options = state.options;
    }

    yes() {
        this.state.modal.close('confirmed');
    }

    no() {
        this.state.modal.dismiss('not confirmed');
    }
}
