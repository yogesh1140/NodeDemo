import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DatepickerOptions } from 'ng2-datepicker';
import * as frLocale from 'date-fns/locale/en';
import { TimeSheetService } from './shared/timesheet.service';
import { ITimeSheet } from './shared/timesheet.model';
import { ToastrService } from 'ngx-toastr';
import { NgbDatepickerConfig, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { saveAs as importedSaveAs } from 'file-saver';
import { ConfirmService } from '../common/confirm.service';

@Component({
    selector: 'app-dashboard',
    templateUrl: 'dashboard.component.html',
    styleUrls: ['dashboard.component.css'],
    providers: [NgbDatepickerConfig],
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {
    date: Date;
    minDate = new Date();
    // mn: any
    tasks: ITimeSheet[] = [];
    unsavedTasks: ITimeSheet[] = [];
    showTasks = false;
    maxDate = new Date();
    options: DatepickerOptions = {
    minYear: new Date().getFullYear(),
    maxYear: new Date().getFullYear() + 1,
    displayFormat: 'MMM D[,] YYYY',
    barTitleFormat: 'MMMM YYYY',
    dayNamesFormat: 'dd',
    firstCalendarDay: 0, // 0 - Sunday, 1 - Monday
    locale: frLocale,
    minDate: this.minDate, // Minimal selectable date
    maxDate: new Date(Date.now()),  // Maximal selectable date
    barTitleIfEmpty: 'Click to select a date',
    placeholder: 'Click to select a date', // HTML input placeholder attribute (default: '')
    addClass: 'form-control', // Optional, value to pass on to [ngClass] on the input field
    addStyle: { 'background-color': 'transparent' }, // Optional, value to pass to [ngStyle] on the input field
    fieldId: 'my-date-picker', // ID to assign to the input field. Defaults to datepicker-<counter>
    useEmptyBarTitle: false, // Defaults to true. If set to false then barTitleIfEmpty will be disregarded and a date will always be shown
    };
    constructor(private timeService: TimeSheetService, private toastr: ToastrService, config: NgbDatepickerConfig) {

        this.minDate.setDate(this.minDate.getDate() - 7 - (new Date()).getDay());


        config.minDate = { year: this.minDate.getFullYear(), month: this.minDate.getMonth() + 1, day: this.minDate.getDate() };
        console.log(config.minDate);

        config.maxDate = { year: 2018, month: 6, day: 30 };

        config.firstDayOfWeek = 7;
        config.outsideDays = 'collapsed';
        config.markDisabled = (date: NgbDateStruct) => {
            const d = new Date(date.year, date.month - 1, date.day);
            return d.getDay() !== 0;
        };
    }

    ngOnInit() {
        // this.timeService.testHttp().subscribe(blob => {
        //     importedSaveAs(blob, 'test.lic');
        //     // console.log(blob)
        // })
    }
    uploadFiles(files) {
        if (files.length === 0) {
            return;
        }

        const formData = new FormData();

        for (const file of files) {
            const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
            if (ext !== '.pdf' && ext !== '.xlsx') {
                this.toastr.error('Invalid file selected for poster');
                return;
            }
            formData.append(file.name, file);
        }


        this.timeService.uploadFile(formData).subscribe(
            data => {
                this.toastr.success(data.msg);
            }
            ,
            err => {
                this.toastr.error(err.msg);
            }

        );
    }

    getTasks() {
        this.tasks = this.timeService.getTasks();
        this.showTasks = true;
        this.unsavedTasks = JSON.parse(JSON.stringify(this.tasks));
    }
    getDate(date: Date, days: number): Date {
        const tempdate = new Date(date);
        tempdate.setDate(tempdate.getDate() + days);
        return tempdate;

    }

    save() {

    }
    cancel() {
        this.showTasks = false;
        this.date = null;
    }
    submit() {

    }
    download() {
        this.timeService.testHttp().subscribe(blob => {
            importedSaveAs(blob, 'test.lic');
            // console.log(blob)
        });
    }
    reset() {
        this.unsavedTasks = JSON.parse(JSON.stringify(this.tasks));
        this.toastr.success('Values been reseted');

    }

}

export class NgbdDatepickerConfig {

    model;

    constructor(config: NgbDatepickerConfig) {
        // customize default values of datepickers used by this component tree
        config.minDate = { year: 1900, month: 1, day: 1 };
        config.maxDate = { year: 2099, month: 12, day: 31 };

        // days that don't belong to current month are not visible and the space should be collapsed
        config.outsideDays = 'collapsed';

        // weekends are disabled
        config.markDisabled = (date: NgbDateStruct) => {
            const d = new Date(date.year, date.month - 1, date.day);
            return d.getDay() === 0 || d.getDay() === 6;
        };
    }
}


