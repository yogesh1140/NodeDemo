import { Component } from '@angular/core';

@Component({
    templateUrl: 'admin-dashboard.component.html'
})
export class AdminDashBoardComponent {

}
