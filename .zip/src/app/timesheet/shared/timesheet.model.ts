export interface ITimeSheet {
    task: string;
    work: IWork[];

}

export interface ITimeSheetWork {
    sunday: number;
    monday: number;
    tuesday: number;
    wednessday: number;
    thursday: number;
    friday: number;
    saturday: number;
}

export interface IWork {
    date: Date;
    hrs: number;
}
