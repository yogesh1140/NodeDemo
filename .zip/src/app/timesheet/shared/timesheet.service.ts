import { Injectable } from '@angular/core';
import { ITimeSheet } from './timesheet.model';
import { HttpClient, HttpRequest, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable()
export class TimeSheetService {
    constructor(private http: HttpClient) { }

    getTasks() {
        return actions;
    }
    testHttp() {
        return  this.http.get('/api/timesheet/template', { responseType: 'blob' });
    }
    uploadFile(formData: FormData): Observable<any> {
        console.log(formData);
        return this.http.post<any>('/api/upload', formData , { responseType: 'json' });
    }

}
const actions: ITimeSheet[] = [
    // {task: 'TASK 1', work: {sunday:0,monday:0, tuesday:0, wednessday:0, thursday:0, friday:0, saturday:0}}
    // ,
    // {task: 'TASK 2', work: {sunday:0,monday:0, tuesday:0, wednessday:0, thursday:0, friday:0, saturday:0}}
    {
        task: 'Task 1', work: [
            { date: new Date(2018, 6, 17), hrs: 1 },
            { date: new Date(2018, 6, 18), hrs: 2 },
            { date: new Date(2018, 6, 19), hrs: 1 },
            { date: new Date(2018, 6, 20), hrs: 3 },
            { date: new Date(2018, 6, 21), hrs: 5.6 },
            { date: new Date(2018, 6, 22), hrs: 4 },
            { date: new Date(2018, 6, 23), hrs: 11 }

        ]
    },
    {
        task: 'Task 2', work: [
            { date: new Date(2018, 6, 17), hrs: 1 },
            { date: new Date(2018, 6, 18), hrs: 2 },
            { date: new Date(2018, 6, 19), hrs: 1 },
            { date: new Date(2018, 6, 20), hrs: 3 },
            { date: new Date(2018, 6, 21), hrs: 5.6 },
            { date: new Date(2018, 6, 22), hrs: 4 },
            { date: new Date(2018, 6, 23), hrs: 11 }

        ]
    }
];

const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
    })
  };
