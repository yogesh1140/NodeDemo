
import {throwError as observableThrowError, of as observableOf} from 'rxjs';
import {catchError, tap, map} from 'rxjs/operators';
import {Injectable} from '@angular/core';
import {IUser} from './user.model';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { ParseSourceSpan } from '@angular/compiler';
@Injectable()
export class AuthService {
    constructor(private http: HttpClient) {}
    users: IUser[] = [{username: 'test', password: '123'}];
    currentUser: IUser;
    //   login(username: string, password: string) {
    //       if (this.users.some(user =>
    //         user.userName.toLocaleLowerCase() === username.toLocaleLowerCase() && user.password === password)) {
    //         this.currentUser = {
    //             userName : username
    //           }
    //       }
    // }
    loginUser(username: string, password: string, remember_me: boolean) {

        // const loginInfo = { username: username, password: password, remember_me: remember_me };
        // return this.http.post<IUser>('/api/users/login', JSON.stringify(loginInfo), {}).pipe(
        // tap(resp => {
        //     // console.log(resp)
        //   if (resp) {
        //     this.currentUser = {username: resp.username};
        //     // console.log('changed', this.currentUser)
        //   }
        // }),catchError(this.handleError),)
        const user = this.users.find(usr => usr.username === username && usr.password === password);
        if (user != null ) {
          this.currentUser = user;

        } else {}

      }
    isAuthenticated() {
        // console.log('ia', this.currentUser)
        if (this.currentUser !== undefined) {
        return true;
        } else { return false;
        }
       //  return !!this.currentUser;
    }
    checkAuthenticationStatus() {
        return this.http.get('/api/users/currentIdentity').pipe(map((response: any) => {
          if (response._body) {
            return response.json();
          } else {
            return {};
          }
        }),
        tap(user => {
           // console.log(user)
          if (user.username) {
             // console.log('updating')
            this.currentUser = user;
          }
        }), );
      }
      logout() {
        this.currentUser = undefined;
        const headers = new Headers({ 'Content-Type': 'application/json'});
        return this.http.post('/api/users/logout', JSON.stringify({}), {});
      }
    checkIfExists(username: string) {
        return this.users.some(user => user.username === username);
    }
    registerUser(email: string, mobile: number, gender: string, password: string, username: string): Observable<any> {
       const user = {
                email: email, gender: gender, mobile: mobile, password: password, username: username
            };
            const headers = new Headers({ 'Content-Type': 'application/json'});
            // const options = new RequestOptions({headers: headers})
            return this.http.post('/api/users/register', JSON.stringify({user: user}), {});
    }
    private handleError(error: Response) {
        console.log('api error');
        return observableThrowError(error.statusText);
    }
}
