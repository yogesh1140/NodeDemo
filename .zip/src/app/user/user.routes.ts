import { LoginComponent } from './login.component';

export const userRoutes = [
  { path: 'login', component: LoginComponent},
];
