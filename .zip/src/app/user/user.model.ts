export  interface IUser {
    username: string;
    email?: string;
    mobile?: number;
    gender?: string;
    password?: string;
}
