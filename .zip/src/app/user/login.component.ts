import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    mouseoverLogin: boolean;
    loginInvalid: boolean;
    constructor(private auth: AuthService, private router: Router) { }

    ngOnInit() { }
    login(formvalues: any) {
        this.auth.loginUser(formvalues.username, formvalues.password, formvalues.remember_me);
        if (this.auth.isAuthenticated) {
            this.loginInvalid = false;
            this.router.navigate(['/dashboard']);
        } else {
            this.loginInvalid = true;
        }

    }
}
