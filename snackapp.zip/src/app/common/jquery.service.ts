import {OpaqueToken, Injectable} from '@angular/core';

export let JQ_Token = new OpaqueToken('jQuery')


