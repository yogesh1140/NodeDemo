import {OpaqueToken, Injectable} from '@angular/core';

export let Toastr_Token = new OpaqueToken('toastr')


