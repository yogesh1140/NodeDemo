
var mongoose = require('mongoose');
const upsertMany = require('@meanie/mongoose-upsert-many');
const MongoClient = require('mongodb').MongoClient;

var XLSX = require('xlsx')

mongoose.plugin(upsertMany);
var test = require('./model')
module.exports.upsert = async function (req, res, next) {

    try {
        const items = [{ _id: '5b3f9587386244c9bc0274fb', name: 'yogesh', age: 27 },
        { name: 'without id', age: 25 }
        ];

        const matchFields = ['_id'];

        const result = await test.upsertMany(items, matchFields);
        res.status(200).send('Update success')
    }
    catch (e) {
        res.status(500).send('Update failed')
    }


}

module.exports.excelRead = function (req, res, next) {

    var workbook = XLSX.readFile(__dirname + '/file.xlsx');
    var sheet_name_list = workbook.SheetNames;
    var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

    if (xlData.length > 0) {
        const programs = [...new Set(xlData.map(item => item.Program))];
        const projects = [...new Set(xlData.map(item => item.Project))];


        (async function () {
            const url = 'mongodb://localhost:27017/my_database';
            const dbName = 'my_database';
            let client;

            try {
                client = await MongoClient.connect(url, { useNewUrlParser: true });

                const db = client.db(dbName);
                const programCollection = db.collection('programs');
                const projectCollection = db.collection('projects');
                const taskCollection = db.collection('tasks');


                const programDocs = await programCollection.find(
                    {
                        programName:
                        {
                            $in: programs
                        }
                    }).toArray();
                const existingPrograms = programs.filter(p => programDocs.find(d => d.programName === p)) || []
                const newPrograms = programs.filter(np => existingPrograms.indexOf(np) < 0)

                const projectDocs = await projectCollection.find(
                    {
                        projectName:
                        {
                            $in: projects
                        }
                    }).toArray();
                const existingProjects = projects.filter(p => projectDocs.find(d => d.projectName === p))
                const newProjects = projects.filter(np => existingProjects.indexOf(np) < 0)

                const taskDocs = await taskCollection.aggregate([
                    {
                        $lookup:
                        {
                            from: "projects",
                            localField: "projectId",
                            foreignField: "_id",
                            as: "project"
                        }
                    }
                ]).toArray();

                const invalidDocs = xlData.filter(d =>

                    (newPrograms.indexOf(d.Program) > -1 || newProjects.indexOf(d.Project) > -1)
                    && (!d.Project_Start || !d.Project_End)
                    || !d.Task
                    || !d.Program
                    || !d.Project
                    || taskDocs.filter(td =>
                        td.taskDescr.trim() == d.Task.trim()
                        && existingProjects.indexOf(td.project[0].projectName) > -1).length > 0
                );


                if (invalidDocs.length > 0) {
                    if (client) {
                        client.close();
                    }

                    res.status(500).send({ msg: 'Invalid or Corrupt Excel Data provided', invalidRows: invalidDocs })


                } else {
                    let programId, projectId;
                    rowCount = xlData.length;
                    xlData.forEach(async xlRow => {
                        if (newPrograms.indexOf(xlRow.Program) > -1) {
                            const newProgram = await programCollection.insertOne(
                                {
                                    programName: xlRow.Program.trim()
                                })
                            programId = newProgram.ops[0]._id;

                        } else {
                            programId = programDocs.find(p => p.programName === xlRow.Program.trim())._id;
                        }
                        if (newProjects.indexOf(xlRow.Project) > -1) {
                            const newProject = await projectCollection.insertOne(
                                {
                                    projectName: xlRow.Project.trim(),
                                    programId: programId
                                })
                            projectId = newProject.ops[0]._id;

                        } else {
                            projectId = await projectDocs.find(p => p.projectName === xlRow.Project.trim())._id
                        }
                        await taskCollection.insertOne(
                            {
                                projectId: projectId,
                                taskDescr: xlRow.Task.trim()
                            })
                        rowCount--;

                    })
                    if (client && rowCount == 0) {
                        client.close();
                    }
                    res.status(200).send({ msg: 'Excel Success' })
                }


            } catch (err) {
                res.status(500).send({ msg: err.stack })
                console.log(err.stack);
            }


        })();


    }

}
