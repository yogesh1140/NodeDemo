var express = require('express');
var Test = require('../test');
var Model = require('../model')
var mongoose = require('mongoose');
const upsertMany = require('@meanie/mongoose-upsert-many');

const MongoClient = require('mongodb').MongoClient;

var XLSX = require('xlsx')


mongoose.plugin(upsertMany);

var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  Model.find({ 'name': 'yogesh' }, '_id name', function (err, result) {
    if (err) return handleError(err);
    res.status(200).send(result);
  })
});


router.get('/read', Test.excelRead)


router.get('/update', Test.upsert);
//  function (req, res, next) {
//   try {

//     Test.test();
//     res.status(200).send('update success:')

//   }
//   catch (e) {
//     res.status(500).send(e)
//   }

// }


module.exports = router;
